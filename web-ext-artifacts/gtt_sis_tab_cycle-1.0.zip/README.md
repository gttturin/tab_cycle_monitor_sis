# Tab cycle

Simple Web Extension that automatically cycles through the tabs in the active browser Window.

Useful for instance for kiosk PCs.

Cycling can be disabled by pressing a toolbar button.

Cycle time is 5 second by default.
